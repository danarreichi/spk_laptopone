<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "spk_laptopone";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
